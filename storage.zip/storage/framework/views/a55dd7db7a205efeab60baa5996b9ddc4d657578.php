

<?php $__env->startSection('content'); ?>
<div class="container py-5">

    
    <div class="card shadow-lg border-0 rounded-4 overflow-hidden animate-fadein">

        
        <div class="card-header text-white text-center py-4" 
             style="background: linear-gradient(135deg, #ff9966, #ff6600, #ff8533);">
            <h2 class="fw-bold mb-0 text-uppercase" style="letter-spacing: 1px;">
                <i class="bi bi-journal-check"></i> Rekap Izin Siswa
            </h2>
        </div>

        <div class="card-body p-4" style="background: linear-gradient(135deg, #fff5f0, #ffe6cc);">

            
            <?php if(session('success')): ?>
                <div class="alert alert-success text-center fw-bold shadow-sm rounded-3 mb-4 animate-slideup">
                    ✅ <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>

            
            <div class="table-responsive">
                <table class="table table-hover align-middle text-center shadow-sm rounded-3 overflow-hidden">
                    <thead class="table-warning">
                        <tr>
                            <th>#</th>
                            <th>Nama</th>
                            <th>Kelas</th>
                            <th>Jurusan</th>
                            <th>Tanggal</th>
                            <th>Alasan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($index + 1); ?></td>
                                <td class="fw-bold"><?php echo e($row->nama ?? 'Tidak diketahui'); ?></td>
                                <td><?php echo e($row->kelas ?? '-'); ?></td>
                                <td><?php echo e($row->jurusan ?? '-'); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($row->tanggal)->format('d M Y')); ?></td>
                                <td><?php echo e($row->keterangan); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-muted text-center">Belum ada izin yang diajukan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            
            <div class="text-center mt-4">
                <a href="<?php echo e(route('izin.create')); ?>" class="btn btn-warning fw-bold shadow-sm">
                    <i class="bi bi-plus-circle"></i> Ajukan Izin
                </a>
            </div>

           
               
            </form>
        </div>
    </div>
</div>


<style>
    body { 
        background: linear-gradient(135deg, #fff0e6, #ffe6cc, #ffd9b3);
        min-height: 100vh;
    }
    .animate-fadein { animation: fadeIn 1s ease; }
    .animate-slideup { animation: slideUp 1s ease; }
    @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
    @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absen-siswa\resources\views/izin/dashboard.blade.php ENDPATH**/ ?>