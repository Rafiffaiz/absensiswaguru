

<?php $__env->startSection('content'); ?>
<div class="container py-5">
    <div class="card shadow-lg border-0 rounded-4 izin-card mx-auto" style="max-width: 600px;">
        <div class="card-body p-4">
            <h2 class="mb-4 text-center fw-bold text-orange-gradient">
                📝 Form Izin
            </h2>

            <form action='/rekap_izin' method="GET">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label class="form-label fw-bold text-muted">Alasan Izin</label>
                    <textarea name="keterangan" rows="4" class="form-control elegant-textarea" placeholder="Masukkan alasan izin..." required></textarea>
                </div>

                <button type="submit" class="btn btn-orange w-100 fw-bold">
                    <i class="bi bi-send-check"></i> Kirim Izin
                </button>
            </form>
        </div>
    </div>
</div>


<style>
    body {
        background: linear-gradient(135deg, #fff3e6, #ffe0cc);
    }
    .text-orange-gradient {
        background: linear-gradient(45deg, #ff6600, #ff9966, #ffcc80);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .izin-card {
        background: linear-gradient(145deg, #ffffff, #fff8f0);
        border: 1px solid rgba(255, 153, 102, 0.4);
        transition: all 0.4s ease;
    }
    .izin-card:hover {
        transform: translateY(-5px) scale(1.02);
        box-shadow: 0 10px 25px rgba(255, 153, 102, 0.6);
    }
    .elegant-textarea {
        border-radius: 12px;
        border: 2px solid #ff9966;
        transition: all 0.3s ease;
    }
    .elegant-textarea:focus {
        border-color: #ff5e62;
        box-shadow: 0 0 12px rgba(255, 94, 98, 0.6);
    }
    .btn-orange {
        background: linear-gradient(45deg, #ff6600, #ff9966, #ffcc80);
        color: #fff;
        border: none;
        border-radius: 12px;
        padding: 12px;
        font-size: 1.1rem;
        box-shadow: 0 5px 20px rgba(255, 153, 102, 0.5);
        transition: all 0.3s ease;
    }
    .btn-orange:hover {
        background: linear-gradient(45deg, #e65c00, #ff5e62);
        transform: translateY(-3px) scale(1.05);
        box-shadow: 0 8px 25px rgba(255, 94, 98, 0.6);
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absen-siswa\resources\views/rekap/izin.blade.php ENDPATH**/ ?>