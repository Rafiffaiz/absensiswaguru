

<?php $__env->startSection('content'); ?>
<div class="container py-5">

    
    <h2 class="mb-5 text-center fw-bold text-orange-gradient">
        <i class="bi bi-journal-check"></i>
        Rekap Izin Guru
    </h2>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success text-center fw-bold shadow-sm rounded-3 mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="card shadow-sm rounded-4">
        <div class="card-body table-responsive">
            <table class="table table-hover align-middle text-center">
                <thead class="table-warning">
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Mapel</th>
                        <th>Tanggal</th>
                        <th>Alasan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $izin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td class="fw-bold"><?php echo e($row->nama ?? 'Tidak diketahui'); ?></td>
                            <td><?php echo e($row->mapel ?? 'Belum diatur'); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($row->tanggal)->format('d M Y')); ?></td>
                            <td><?php echo e($row->keterangan); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-muted text-center">Belum ada izin yang diajukan</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    
    <div class="text-center mt-4">
        <a href="<?php echo e(route('izin.guru.create')); ?>" class="btn btn-warning fw-bold">
            <i class="bi bi-plus-circle"></i> Ajukan Izin
        </a>
    </div>
</div>


<style>
    .text-orange-gradient {
        background: linear-gradient(135deg, #ff9966, #ff6600);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absen-siswa\resources\views/izin/guru/dashboard.blade.php ENDPATH**/ ?>