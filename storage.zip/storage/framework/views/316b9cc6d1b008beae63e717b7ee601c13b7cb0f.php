

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Rekap Izin Kelas <?php echo e($kelas); ?></h2>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Tanggal</th>
                <th>Keterangan</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($absen->siswa->username); ?></td>
                    <td><?php echo e($absen->siswa->kelas); ?></td>
                    <td><?php echo e($absen->tanggal); ?></td>
                    <td><?php echo e($absen->keterangan); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="text-center">Belum ada data izin</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-secondary">Kembali</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\absen-siswa\resources\views/rekap_izin.blade.php ENDPATH**/ ?>